//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OPTModuleTest.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_OPTMODULETEST_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     130
#define IDD_Content                     133
#define IDD_DLGDOWNLIB                  137
#define IDC_BUTTON1                     1000
#define IDC_COMBO1                      1001
#define IDC_BUTTON44                    1001
#define IDC_COMBO2                      1002
#define IDC_EDIT1                       1003
#define IDC_BUTTON2                     1004
#define IDC_BUTTON3                     1005
#define IDC_EDIT11                      1005
#define IDC_EDIT2                       1006
#define IDC_INFOPAGE                    1006
#define IDC_BUTTON4                     1007
#define IDC_BUTTON5                     1008
#define IDC_EDIT12                      1008
#define IDC_BUTTON6                     1009
#define IDC_EDIT13                      1009
#define IDC_BUTTON7                     1010
#define IDC_BUTTON8                     1011
#define IDC_BUTTON9                     1012
#define IDC_BUTTON10                    1013
#define IDC_BUTTON11                    1014
#define IDC_BUTTON12                    1015
#define IDC_BUTTON13                    1017
#define IDC_BUTTON14                    1018
#define IDC_BUTTON15                    1019
#define IDC_BUTTON16                    1020
#define IDC_BUTTON17                    1021
#define IDC_BUTTON18                    1022
#define IDC_BUTTON19                    1023
#define IDC_BUTTON20                    1024
#define IDC_BUTTON21                    1025
#define IDC_BUTTON22                    1026
#define IDC_BUTTON23                    1027
#define IDC_BUTTON24                    1028
#define IDC_BUTTON25                    1029
#define IDC_BUTTON26                    1030
#define IDC_BUTTON27                    1031
#define IDC_COMBO3                      1032
#define IDC_BITMAP                      1033
#define IDC_COMBO4                      1034
#define IDC_EDIT3                       1035
#define IDC_EDIT4                       1036
#define IDC_EDIT5                       1037
#define IDC_DELSTART                    1037
#define IDC_EDIT6                       1038
#define IDC_DELNUM                      1038
#define IDC_EDIT7                       1039
#define IDC_EDIT8                       1040
#define IDC_BUTTON28                    1041
#define IDC_BUTTON29                    1042
#define IDC_COMBO5                      1044
#define IDC_EDIT9                       1045
#define IDC_COMBO6                      1046
#define IDC_COMBO7                      1047
#define IDC_BUTTON30                    1048
#define IDC_BUTTON31                    1049
#define IDC_BUTTON32                    1050
#define IDC_BUTTON33                    1051
#define IDC_SYSINFO                     1052
#define IDC_BUTTON34                    1053
#define IDC_EDIT10                      1054
#define IDC_BUTTON35                    1055
#define IDC_TFRR                        1057
#define IDC_TFAR                        1058
#define IDC_PROGRESS1                   1059
#define IDC_BUTTON36                    1060
#define IDC_GENTZ                       1061
#define IDC_BINIMG                      1062
#define IDC_BUTTON37                    1063
#define IDC_ISPTYPE                     1064
#define IDC_BUTTON38                    1065
#define IDC_BUTTON39                    1066
#define IDC_BUTTON40                    1067
#define IDC_BUTTON41                    1068
#define IDC_INFO                        1070
#define IDC_Group2                      1071
#define IDC_BUTTON42                    1073
#define IDC_ProgressName                1074
#define IDC_BUTTON43                    1075
#define IDC_CHECK1                      1076
#define IDC_BUTTON45                    1077
#define IDC_BUTTON46                    1078

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1079
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
