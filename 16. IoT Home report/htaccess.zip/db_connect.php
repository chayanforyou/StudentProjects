<?php
    // Prepare variables for database connection
    $username = "f1d24f737f37";  
    $password = "a2831094f609f801"; 
    $server = "localhost";
    $database = "id1182168_mrcycho"; 

    // Create connection
    $conn = new mysqli($server, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
       die("Connection failed: " . $conn->connect_error);
    } 
?>