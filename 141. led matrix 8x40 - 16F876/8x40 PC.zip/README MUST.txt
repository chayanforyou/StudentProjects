

------PC serial based LED Matrix 8x40-------

>>>>> Its JUST a DEMO Version <<<<<<

[DEMO Limitation: 30 Char Only]

*** Educational purposes only

**** Software needed:
	1. Termite 3.1 by CompuPhase.
	2. Virtual serial ports emulator.[need for Proteus simulation]

**** Instractions:
	1. Install Virtual serial ports emulator.
	2. Creat a new port.
	3. Open proteus project file.[Proteus 8 needed]
	4. Set COMPIM physical port to created virtual port of VSPE.
	5. Open Termite 3.1.
	6. Setup Termite as shown in video.
	7. Run Simulation.
	8. Send your MSG to LED Matrix by termite.
