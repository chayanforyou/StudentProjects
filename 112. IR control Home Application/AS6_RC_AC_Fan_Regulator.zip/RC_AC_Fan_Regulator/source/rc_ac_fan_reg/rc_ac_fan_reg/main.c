/******************************************************************************
This device can be used to remotely control the speed of an AC fan and to 
switch it on or off. The remote control is a cheap NEC Format remote, usually 
supplied with small DVD players. Three buttons are used to command the circuit. 
The UP key increase the fan�s speed while the DOWN key decrease it. The ENTER 
key is used to switch on or off the fan. The unit provides 10 way speed control 
from 0 to 9. The current speed is displayed in a seven segment display. The 
yellow LED on the PCB indicates the power status of the load. If the load is 
switched off using the R/C then the LED will also be switched off.

MCU: ATmega8A
Speed: 16MHz External Crystal
Fuse Low: FF
Fuse High: C9

Written By
 Avinash Gupta
Contact
 gmail@avinashgupta.com

For more interesting microcontroller tutorials and projects. Please visit
http://www.extremeelectronics.co.in

NOTICE:
PROGRAM SAMPLE PROVIDED FOR SELF LEARNING PURPOSE ONLY!
NO PART OF THIS WORK SHOULD BE USED IN ANY COMMERCIAL PROJECTS OR IN ANY 
TEACHING INSTITUTES FOR TEACHING THEIR STUDENTS
NO PART OF THIS WORK SHOULD BE PUBLISHED IN ANY FORM LIKE PRINTED OR ELECTRONIC
MEDIA

COPYRIGHT (C) 2008-2015 EXTREME ELECTRONICS, INDIA
******************************************************************************/ 


#include <avr/io.h>
#include <util/delay_basic.h>
#include <avr/interrupt.h>

#include "lib/remote/remote.h"
#include "lib/remote/rckeys.h"

#define FAN_POWER_LED_PORT PORTD
#define FAN_POWER_LED_DDR DDRD
#define FAN_POWER_LED_BIT 7

#define POWER_LED_ON() 	FAN_POWER_LED_PORT&=(~(1<<FAN_POWER_LED_BIT))
#define POWER_LED_OFF()	FAN_POWER_LED_PORT|=(1<<FAN_POWER_LED_BIT)

uint8_t table[10]={141,125,109,94,78,62,47,31,16,1};

uint8_t speed=0;
uint8_t fan_on=0;

void Display(uint8_t num);

void Initialize()
{
	FAN_POWER_LED_DDR|=0B10000000;

	POWER_LED_OFF();

	DDRC|=0b00111111;	//Seven segment
	DDRB|=0b00000010;	//Middle segment G

	Display(0);

	RemoteInit();

	//Initialize the zero crossing detector INT(1)
	
	MCUCR|=((1<<ISC11)|(1<<ISC10));		//INT in Rising edge
	GICR|=(1<<INT1);					//Enable INT1

	//Output
	DDRD|=(1<<PD5);
	PORTD|=(1<<PD5);	//High = TRIAC Off


	//Set Timer 2
	TCCR2|=(1<<WGM21);	//CTC
	TIMSK|=(1<<OCIE2);	//Enable OCI2

	sei();

}
/*

Zero Crossing Detect.

*/
ISR(INT1_vect)
{
	if(!fan_on)
	{
		PORTD|=(1<<PD5);	//High = TRIAC Off
		return;
	}
	
	if(speed==9)
	{
		PORTD&=(~(1<<PD5)); //low = TRIAC ON
		return;
	}
	
	PORTD|=(1<<PD5);	//High = TRIAC Off

	OCR2=table[speed];

	TCNT2=0x00;

	TCCR2|=((1<<CS22)|(1<<CS21)|(1<<CS20));	//Start Timer prescaler =1024

}

/*

Timer2 Compare ISR

*/
ISR(TIMER2_COMP_vect)
{
	PORTD&=(~(1<<PD5)); //low = TRIAC ON

	TCCR2&=(~((1<<CS22)|(1<<CS21)|(1<<CS20)));	//Stop Timer
}

/*

Simple Wait Function

*/
void Wait()
{
	char i;

	for(i=0;i<100;i++)
	_delay_loop_2(0);
}

/*

Displays a number in Seven Seg Display

*/
void Display(uint8_t num)
{
	if(num>9)
	return;
	
	switch (num)
	{
		case 0:
		PORTC=0B00000000;
		PORTB|=0B00000010;
		break;
		case 1:
		//      xxfedcba
		PORTC=0B00111001;
		PORTB|=0B00000010;
		break;
		case 2:
		//      xxfedcba
		PORTC=0B00100100;
		PORTB&=(~(0B00000010));
		break;
		case 3:
		//      xxfedcba
		PORTC=0B00110000;
		PORTB&=(~(0B00000010));
		break;
		break;
		case 4:
		//      xxfedcba
		PORTC=0B00011001;
		PORTB&=(~(0B00000010));
		break;
		case 5:
		//      xxfedcba
		PORTC=0B00010010;
		PORTB&=(~(0B00000010));
		break;
		case 6:
		//      xxfedcba
		PORTC=0B00000010;
		PORTB&=(~(0B00000010));
		break;
		case 7:
		//      xxfedcba
		PORTC=0B00111000;
		PORTB|=0B00000010;
		break;
		case 8:
		//      xxfedcba
		PORTC=0B00000000;
		PORTB&=(~(0B00000010));
		break;
		case 9:
		//      xxfedcba
		PORTC=0B00010000;
		PORTB&=(~(0B00000010));
		break;
	}
}

void main()
{

	uint8_t cmd; //Command received from remote

	Initialize();

	while(1)
	{
		//Get Command For the Remote Control
		cmd=GetRemoteCmd(1);

		//Now process the command

		//UP Key
		if(cmd==RC_UP)
		{
			if(speed<9)
			speed++;

		}

		//DOWN Key
		if(cmd==RC_DOWN)
		{
			if(speed>0)
			speed--;
		}

		//Enter Key
		if(cmd==RC_ENTER)
		{
			if(fan_on)
			{
				POWER_LED_OFF();
				fan_on=0;	//Turn Off
			}
			else
			{
				POWER_LED_ON();
				fan_on=1;	//Turn On
			}
		}

		Display(speed);

	}
}