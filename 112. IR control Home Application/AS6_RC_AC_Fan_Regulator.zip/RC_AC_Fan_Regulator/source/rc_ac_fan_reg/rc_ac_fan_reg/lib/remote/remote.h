/*

IR remote interfacing library for AVR series of microcontrollers.
Target MCU ATmege8 @ 8MHz/12MHz/16MHz

Note:
Timer0 was used in my original version for mega8515 MCU but since Timer0 of mega8
does not have output compare so i have to use 16-Bit Timer Timer1. But for mega16
and mega32 Timer0 can be used.

Sensor: TSOP1738 IR receiver module must be connected to INT0 Pin.
		This is PIN4 in ATmega8

		 -----
		|  _  |
		| | | |
		| | | |
		-------
		| |  |
		| |  | 
		| |  |
	(GND) | (To INT0)
        (5v)	

		**********************
		*TSOP 1738 Front View*
		**********************


Copyright Avinash Gupta 2008
extremeelectronics.co.in

Please give credit to www.eXtremeElectronics.co.in if you use
it in your projects and find it useful.


Resource Usage:
-Timer1
-INT0 (PD2)


Copyright Avinash Gupta 2008-2010
extremeelectronics.co.in

MUST BE DISTRIBUTED WITH THIS COPYRIGHT INTACT

*/

#ifndef _REMOTE_H
 #define _REMOTE_H
 /*____________________________________________________________________________________________*/

//Constants
//*********

//States
#define IR_VALIDATE_LEAD_HIGH 0
#define IR_VALIDATE_LEAD_LOW 1
#define IR_RECEIVE_BITS 3
#define IR_WAIT_STOP_BIT 4

//Others
#define TOL 0.1			//Tollerence for timming
#define QMAX 8			//Size of the Remote command buffer
#define RC_NONE 255		//This val is returned by GetRemoteCmd when no key is pressed


//Functions
//*********

void ResetIR();
void RemoteInit();
unsigned char GetRemoteCmd(char wait);

 /*____________________________________________________________________________________________*/
#endif
